<?php    
ini_set('display_errors',true);
error_reporting(E_ALL & ~E_DEPRECATED);
?>
<div id="nav">
<a href="index.php">首页</a>
<a href="noads.php">无广告播放方法</a>
<a href="category.php">各频道视频</a>
<a href="hot.php">漂亮瀑布流</a>
<a href="player.php">播放器示例</a>
<a target="_blank" href="/SDK/demo/SDK.zip">下载demo</a>
</div>
<style>
    #nav {padding:10px; margin:0 auto;text-align:center}
    #nav a {text-align:center;font-size:16px;padding-right:20px;}
</style>
