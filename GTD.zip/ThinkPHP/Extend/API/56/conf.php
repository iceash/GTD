<?php
return array(
    'is_developer'=>false,
    'print_request_params'=>false,
    'appkey'      =>'3000002936',
    'secret'      =>'ec0423a8a20a606d',
    'domain'      =>'http://oapi.56.com',
    'token'       =>'',
    'test_user_id'=>'',
    );
