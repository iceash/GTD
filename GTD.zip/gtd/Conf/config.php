<?php
return array(
    'URL_MODEL'=>1, // 如果你的环境不支持PATHINFO 请设置为3
    'DB_TYPE'=>'mysql',
    'DB_PORT'=>'3306',
    'DB_PREFIX'=>'',
    // 'TMPL_CACHE_ON'=>false,
    // 'VAR_PAGE'=>'p',

    'DB_HOST'=>'127.0.0.1',
    'DB_NAME'=>'gtd',
    'DB_USER'=>'root',
    'DB_PWD'=>'',
);
?>