<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>GTD管理系统</title>
	<!-- jQuery -->
	<script type="text/javascript" src="__PUBLIC__/js/jquery-3.1.1.min.js" ></script>
	<!-- 最新版本的 Bootstrap 核心 CSS 文件 -->
	<link rel="stylesheet" href="__PUBLIC__/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" href="__PUBLIC__/css/dashboard.css" >

	<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
	<script src="__PUBLIC__/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
  <body>
    <nav class="navbar navbar-default navbar-fixed-top">
    	<div class="container">

      <!-- Static navbar -->
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#">GTD系统</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            	<li class="dropdown <?php echo ($active["0"]); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">看板 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="__URL__/index">首页看板</a></li>
                  <li role="separator" class="divider"></li>
                  <li><a href="__URL__/calendar">日历看板</a></li>
                  <!-- <li><a href="#">树形看板</a></li> -->
                </ul>
              </li>
              <li class="<?php echo ($active["1"]); ?>"><a href="__URL__/basket">工作篮</a></li>
              <li class="<?php echo ($active["2"]); ?>"><a href="__URL__/project">项目</a></li>
              <li class="<?php echo ($active["3"]); ?>"><a href="__URL__/memo">备忘录</a></li>
              <li class="<?php echo ($active["4"]); ?>"><a href="__URL__/reference">参考资料</a></li>
              
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->

     

    	</div> <!-- /container -->
    </nav>
<link href="__PUBLIC__/css/style.css" rel="stylesheet">

<style>
.row-fluid  .zAccountPlanRinner { position:relative;}
.waveBox{ position:absolute; left:0; bottom:0; width:100%; height:61px;overflow:hidden;}
.waveInner{position:absolute; left:0; bottom:0; width:1200px; height:61px; }
.waveInner img{ float:left; display:block;}
.zAccountPlanR .detail {
	color: #fb653b;
	position: relative;
	z-index: 3;
}
.row-fluid .zAccountPlanR { background-image:none;}
.sidebar{background-color: #f5f5f5;}
.row-outer{margin-right: 0;}
</style>
<div class="row row-outer">
	<div class="col-sm-3 col-md-2 sidebar">
		<p>本月计划：</p>
		<div id="month_plan"></div>
		<p>本年计划：</p>
		<div id="year_plan"></div>
	</div>
	<div class="col-sm-9 col-sm-offset-3 col-md-8 col-md-offset-2 main">
		<div class="zAccountInner zAccount2 clearfix">
			<div class="colorsBox clearfix">
				<div><span class="yellow box"></span>本周计划</div>
				<div><span class="blue box"></span>日程</div>
			</div>
			<div class="zAccountPlanL span5 no-margin-left" style="position:absolute;left:0px;top:50px;width:900px;">
				<div id="div1"></div> <input type="hidden" id="index_clander" />
				<input type="hidden" id="d523_y">
			</div>
			
		</div>
	</div>
	<div class="col-md-2">
		<div class="span7" style="height: 320px;position:absolute;right:0;text-align:center;top:50px;width:290px;background-color:#f5f5f5;">
				<div class="zAccount5 boxSize no-margin-left">
					<div class="zAccountPlanRinner zAccountPlanR">
						<div class="today">今天日程</div>
						<div class="week" id="d523_w">星期三</div>
						<div class="day" id="d523_d">27</div>
						
						 <p id="d523_day">今天要去做XXXXX</p>
						 <div id="day_a">
							<a id="d523_href" href="#" class="detail">详情</a>
						 </div>
						 <p id="d523_week">XXXXX项目完工</p>
						 <div id="week_a">
							<a id="d523_href" href="#" class="detail">详情</a>
						 </div>
						<!-- <div class="waveBox">
						  <div class="line_water waveInner">
							   <img src="__PUBLIC__/images/zz111.png">
							   <img src="__PUBLIC__/images/zz111.png">
							</div>
							<div class="line_water2 waveInner">
							   <img src="__PUBLIC__/images/zz222.png">
							   <img src="__PUBLIC__/images/zz222.png">
							</div>
						</div> -->
					</div>
				</div>
			</div>
	</div>
</div>
	
	



<script type="text/javascript" src="__PUBLIC__/js/DatePicker/WdatePicker.js"></script>
<!-- <script type="text/javascript" src="__PUBLIC__/js/DatePicker/extraDate.js"></script> -->
<script>
//运动的水波纹
	function rollTwo(){
	  $(".line_water").animate({marginLeft:"-297px"},5000,"linear",function(){
		$(this).css({marginLeft:"0px"});
		$(this).find("img:first").remove().clone(true).appendTo($(this));	
	  })	
	}
	rollTwo()
	var startRollTwo=setInterval(rollTwo,40);
	
	function rollOne(){
	  $(".line_water2").animate({marginLeft:"-297px"},5000,"linear",function(){
		$(this).css({marginLeft:"0px"});
		$(this).find("img:first").remove().clone(true).appendTo($(this));	
	  })	
	}
	rollOne()
	var startRollTwo=setInterval(rollOne,20);



$(function(){
		//点击今天时间获取
		var weeks=['星期日','星期一','星期二','星期三','星期四','星期五','星期六']
		todays();
		
		$(".today").click(function(){
			todays();
			$(iframe).contents().find('#todayss').click();	
		})
		function todays(){
			var myDate = new Date();
			$("#d523_d").text( myDate.getDate());
			$("#d523_w").text(weeks[myDate.getDay()]);
		}

		//日历插件配置
		// 数组信息可根据后台需求变化
		 var myDate = new Date();
		 var year=myDate.getFullYear();
		 var month=myDate.getMonth()+1;
		 var day=myDate.getDate();
		 // 操作年计划
		 var json_year_plans = '<?php echo json_encode($year_plans); ?>';
		 var year_plans = eval('('+json_year_plans+')');
		 function thisyearplan(year){
		 	var contents = "";
		 	for (var i = 0; i < year_plans.length; i++) {
		 		var this_year_plan = year_plans[i];
		 		if (this_year_plan["start_time"] == year) {
		 			contents += "<p><a href='__URL__/change_year_plan?id="+this_year_plan["id"]+"&redirect=basket' class='detail'>"+(i+1)+"、"+this_year_plan["content"]+"</a></p>";
		 		}; 
		 	};
		 	$("#year_plan").html(contents);
		 }
		 thisyearplan(year);
		 // 操作月计划
		 var json_month_plans = '<?php echo json_encode($month_plans); ?>';
		 var month_plans = eval('('+json_month_plans+')');
		 function thismonthplan(year_month){
		 	var contents = "";
		 	for (var i = 0; i < month_plans.length; i++) {
		 		var this_month_plan = month_plans[i];
		 		if (this_month_plan["start_time"] == year_month) {
		 			contents += "<p><a href='__URL__/change_month_plan?id="+this_month_plan["id"]+"&redirect=basket' class='detail'>"+(i+1)+"、"+this_month_plan["content"]+"</a></p>";
		 		}; 
		 	};
		 	$("#month_plan").html(contents);
		 }
		 thismonthplan(year+"-"+month);
		 // 操作周计划
		 var json_week_plans = '<?php echo json_encode($week_plans); ?>';
		 var week_plans = eval('('+json_week_plans+')');
		 var noDateArr = [];//周计划列表数组
		 for (var i = 0; i < week_plans.length; i++) {
		 	var thisweek = {};
		 	thisweek.time = week_plans[i]["start_time"];
		 	thisweek.x = week_plans[i]["content"];
		 	thisweek.y = "进度："+week_plans[i]["rate"]+"%";
		 	thisweek.id = week_plans[i]["id"];
		 	noDateArr[i] = thisweek;
		 };
		 // 操作日程
		 var json_day_plans = '<?php echo json_encode($day_plans); ?>';
		 var day_plans = eval('('+json_day_plans+')');
		 var limitDaysArr = [];//日程列表数组
		 for (var i = 0; i < day_plans.length; i++) {
		 	var thisday = {};
		 	thisday.time = day_plans[i]["start_time"];
		 	thisday.x = day_plans[i]["content"];
		 	thisday.y = "进度："+day_plans[i]["rate"]+"%";
		 	thisday.id = day_plans[i]["id"];
		 	limitDaysArr[i] = thisday;
		 };
		 function show_plan (click_date) {
			var click_day = hasdate(limitDaysArr,click_date);
			var click_week = hasdate_week(noDateArr,click_date);
			if (click_day !== '') {
				$('#d523_day').text("今日："+limitDaysArr[click_day].x);
				$('#day_a').html('<a id="d523_href" href="__URL__/change_day_plan?id='+limitDaysArr[click_day].id+'&redirect=basket" class="detail">详情</a>');
			}else{
				$('#d523_day').text("今日无安排");
				$('#day_a').html("");
			};
			if (click_week !== '') {
				$('#d523_week').text("本周："+noDateArr[click_week].x);
				$('#week_a').html('<a id="d523_href" href="__URL__/change_week_plan?id='+noDateArr[click_week].id+'&redirect=basket" class="detail">详情</a>');
			}else{
				$('#d523_week').text("本周无安排");
				$("#week_a").html("");
			};
		 }
		 show_plan(year+"-"+month+"-"+day);
		var d = new Date();
		var str = d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();
		WdatePicker({eCont:'div1',dateFmt:'yyyy-MM-dd',readOnly:true,isShowClear:false,isShowToday:true,isShowOK:true,qsEnabled:false,quickSel:null,skin:'whyGreen',onpicked:function(dp){
			// 这里是点击事件，非常重要！
			thisyearplan(dp.cal.date.y);
			thismonthplan(dp.cal.date.y+"-"+dp.cal.date.M);
			dp.$('index_clander').value=dp.cal.getNewDateStr();
			var week=dp.cal.date.d;
			// 边栏日程
			var click_date = dp.cal.date.y+"-"+dp.cal.date.M+"-"+dp.cal.date.d;
			dp.$('d523_d').innerText=dp.cal.date.d;
			dp.$('d523_w').innerText=dp.cal.getDateStr('DD');

			show_plan (click_date);

			 
			$(iframe).contents().find('.WdateDiv').find('td').each(function(){
			        var dates='';
					if($(this).attr('onclick')){
						dates=($(this).attr('onclick').split('(')[1]).split(')')[0].split(',').join('-');
					}
					var nodates=hasdate(noDateArr,dates);
					 var limitdates=hasdate(limitDaysArr,dates);
					if(nodates!==''){
						$(this).addClass('Wshover WspecialDay')
					}else if(limitdates!==''){
						$(this).addClass('Wshover limitDays')
					}else if(dates==str){
						$(this).addClass('today')
					}
			   })
		} })
		//日历自适应大小
		function changeSize(){
			var ww=$("#div1").width()
			$('iframe').css({"width":ww+'px'})
			$(iframe).contents().find('.WdateDiv').css({"width":ww+'px'})
		}
		$(window).resize(function(){
			changeSize();
		})
		load();

		setTimeout(function(){
			dateOperate();
			var today=new Date();
			 var y= today.getFullYear();//查询年份
             var monthNow=parseInt(today.getMonth())+1;
             var dayNow=today.getDate();//日期
			//$(iframe).contents().find(".WdateDiv").append('<div id="todayss" onclick="day_Click(2016,9,21);">1234</div>')
			$(iframe).contents().find(".WdateDiv").append('<div id="todayss" onclick="day_Click('+y+','+monthNow+','+dayNow+');">&nbsp;</div>')
		},200);
		function comparedate(d1,d2){
			var d1_arr = d1.split("-");
			var d2_arr = d2.split("-");
			var b = true;
			for (var i = 0; i < 3; i++) {
				if (parseInt(d1_arr[i]) != parseInt(d2_arr[i])) {
					b = false;
					break;
				};
			};
			return b;
		}
		function compareweek(d1,d2){
			var d1_arr = d1.split("-");
			var d2_arr = d2.split("-");
			var b = false;
			var d1_date = new Date(d1_arr[0], d1_arr[1]-1, d1_arr[2]);
			var d2_date = new Date(d2_arr[0], d2_arr[1]-1, d2_arr[2]);
			var cha = (d2_date - d1_date)/(24*3600*1000);
			if (cha >= 0 && cha < 7) {
				b = true;
			};
			return b;
		}
		function hasdate(obj,d){
		   var dates='';
		   var len=obj.length;
		   if(len>0){
		     for(var i=0;i<len;i++){
			    var t=obj[i].time;
				if(comparedate(t,d)){
				  dates=i;
				}
			 }
		   }
		   return dates
		}
		function hasdate_week(obj,d){
		   var dates='';
		   var len=obj.length;
		   if(len>0){
		     for(var i=0;i<len;i++){
			    var t=obj[i].time;
				if(compareweek(t,d)){
				  dates=i;
				}
			 }
		   }
		   return dates
		}
		
		//alert(hasdate(noDateArr,'2016-8-8'))
        function dateOperate(){
			var len=$(iframe).contents().find('.WdayTable').find('td').length;
			initDate();   //初始化 日历   改变年份月份都需初始化
			$(iframe).contents().find('.WdateDiv').find('.navImg').click(function(){
				initDate();
			})
			$(iframe).contents().find('.WdateDiv').find('.yminput').blur(function(){
				initDate();
			})
			$(iframe).contents().find('.WdateDiv').on('mousemove','td',function(){  // 鼠标经过每个日历单元格 判断是否有对应的日期和弹出层
				var dates='';
				if($(this).attr('onclick')){
					dates=($(this).attr('onclick').split('(')[1]).split(')')[0].split(',').join('-');
				}
				
                 var nodates=hasdate(noDateArr,dates);
				 
				 var limitdates=hasdate(limitDaysArr,dates);
				if(nodates!==''){
					$(this).addClass('Wshover WspecialDay')
					var tops=noDateArr[nodates].x;
					var bots=noDateArr[nodates].y;
					createElements(this,tops,bots)
				}else if(limitdates!==''){
					$(this).addClass('Wshover limitDays')
					var tops=limitDaysArr[limitdates].x;
					var bots=limitDaysArr[limitdates].y;
					createElements(this,tops,bots)

				}else if(dates==str){
					$(this).addClass('today')
				}
			})
			$(iframe).contents().find('.WdateDiv').on('mouseout','td',function(){
				//鼠标离开每个日历单元格 判断是否有对应的日期和弹出层
				var dates='';
				if($(this).attr('onclick')){
					dates=($(this).attr('onclick').split('(')[1]).split(')')[0].split(',').join('-');
				}
				var nodates=hasdate(noDateArr,dates);
				 var limitdates=hasdate(limitDaysArr,dates);
				if(nodates!==''){
					$(this).addClass('Wshover WspecialDay')
				}else if(limitdates!==''){
					$(this).addClass('Wshover limitDays')
				}else if(dates==str){
					$(this).addClass('today')
				}
				$(this).find(".angleinner").remove();
				$(this).find(".angle").remove();
				$(this).find(".txt").remove();
			})

		}
		//初始化日历  根据时间判断 是否日期在还款或已还款数组中  标记颜色
		function initDate(){

			$(iframe).contents().find('.WdateDiv').find('td').each(function(){
				var dates='';
				if($(this).attr('onclick')){
					dates=($(this).attr('onclick').split('(')[1]).split(')')[0].split(',').join('-');
				}
                 var nodates=hasdate(noDateArr,dates);
				 var limitdates=hasdate(limitDaysArr,dates);
				if(nodates!==''){
					$(this).attr('onmouseover','')
					$(this).attr('onmouseout','')
					$(this).addClass('Wshover WspecialDay')
				}else if(limitdates!==''){
					$(this).attr('onmouseover','')
					$(this).attr('onmouseout','')
					$(this).addClass('Wshover limitDays')
				}else if(dates==str){
					$(this).addClass('today')
				}
			})
		}
		var iframe;
		function load() {
			iframe = $('iframe')[0];
			iframe.onload = iframe.onreadystatechange =function(){
				iframeload()
			}
		}

		function iframeload() {
			if (!iframe.readyState || iframe.readyState == "complete") {
				setTimeout(function(){
					changeSize();
					initDate();
					dateOperate();
				},100)
			}
		}
	})
	//向 日历表格中添加弹出层信息
	function createElements(obj,tops,bots){
		var topY=obj.offsetTop;//206
		var leftX=obj.offsetLeft;
		var leftR=obj.offsetWidth*7+8-leftX;
		var txts= document.createElement("div");
		var spans=document.createElement("span");
		var ems=document.createElement("em");
		if(topY>206){
			ems.className='angleinner  top';
			spans.className='angle  top';
			txts.className='txt top';
		}else{
			txts.className='txt';
			ems.className='angleinner';
			spans.className='angle';
		}
		txts.innerHTML="<p>"+tops+"</p>"+"<p>"+bots+"</p>";
		var lefts=0;
		if(leftX>101){
			if(leftR<101){
			    if(leftR>52){
				  lefts=-(leftR-44)-101;
				}else{

				  lefts=22-202
				}
				
			}else{
				lefts=-101;
			}
		}else{
			if(lefts<101){
				if(lefts<52){
				  lefts=-leftX-22; 
				}else{
				  lefts=-leftX;
				}
			}else{
				lefts=-101;
			}

		}
		txts.style.marginLeft=lefts+'px';
		obj.appendChild(spans);
		obj.appendChild(ems);
		obj.appendChild(txts);

	}
</script>

	
  </body>
</html>